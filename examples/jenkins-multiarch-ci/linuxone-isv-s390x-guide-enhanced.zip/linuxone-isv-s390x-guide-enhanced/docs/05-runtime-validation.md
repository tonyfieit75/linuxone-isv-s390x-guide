# Runtime & Operator Validation

Validate:
- Stateful workloads
- Persistent volumes
- Rolling upgrades
- Performance behavior
