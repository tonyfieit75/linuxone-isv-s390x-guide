# TAT Banking Multi-Architecture Reference

https://github.com/tonyfieit/TAT-Banking

Demonstrates multi-arch builds and OpenShift deployment patterns.
